package com.example.elancer2_azkar_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
